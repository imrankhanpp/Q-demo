TEACHER'S CAFE — WEBSITE DEMO

Files:
- index.html: complete responsive website (HTML, CSS and JavaScript in one file)

How to preview:
1. Open index.html in a browser, or open the folder in Acode and use Preview.
2. Internet is needed for the two Unsplash photos. Menu cards use built-in emoji illustrations as placeholders.

Included:
- Responsive cafe landing page
- Menu category filters
- Add-to-cart and quantity controls
- Estimated cart total
- WhatsApp order-request message to the number shown in the supplied reference
- Location / directions link

Important before showing this as a final client website:
- This is a visual demo/prototype, not a completed production ordering system.
- Confirm the cafe's permission to use its brand, photos, phone number and address.
- Confirm all menu items, prices, opening hours, food details and delivery/pickup policy.
- Online payment, order database, inventory, admin dashboard and automatic order acceptance are not implemented.
- Change the WhatsApp number in the `wa.me/918200627391` links if the cafe confirms a different number.
